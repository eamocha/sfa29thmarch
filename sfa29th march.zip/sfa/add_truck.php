
						<!-- Modal -->
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title" id="myModalLabel">Vehicle details</h4>
						      </div>
						      <div class="modal-body">
						       
                <form name="signupForm" action="add_truck_exec.php" method="post" id="signupForm" >
                               <table id="add_truck"  style="margin:auto;"><tr><td>Reg No.</td><td><input type="text" class=" form-control" id="regno" name="regno"></td><td>Capacity</td><td><input type="text" class=" form-control" id="cap" name="cap"></td></tr><tr><td> Description</td><td><input type="text" class="form-control"  id="descr" name="descr"></td><td></td><td></td></tr>
                              </table>
                              <div class="modal-footer">
						        <button type="reset" class="btn btn-default" data-dismiss="modal">Reset</button>
						        <button  type="submit" id="submit" class="btn btn-primary" >Save</button>
						      </div></form>
						    </div>
						  </div>
						</div>      				
      				</div><!-- /showback -->
						<!-- Modal -->
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						  <div class="modal-dialog modal-lg">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title" id="myModalLabel">Vehicle details</h4>
						      </div>
						      <div class="modal-body">
						       
                <form name="signupForm" action="add_truck_exec.php" method="post" id="signupForm" >
                               <table id="add_truck"  style="margin:auto;"><tr><td>Reg No.</td><td><input type="text" class=" form-control" id="regno" name="regno"></td><td>Capacity</td><td><input type="text" class=" form-control" id="cap" name="cap"></td><td> Description</td><td><input type="text" class="form-control"  id="descr" name="descr"></td></tr>
                              </table>
                              <div class="modal-footer">
						        <button type="reset" class="btn btn-default" data-dismiss="modal">Reset</button>
						        <button  type="submit" id="submit" class="btn btn-primary" >Save</button>
						      </div></form>
						    </div>
						  </div>
						</div>      				
      				</div><!-- /showback -->