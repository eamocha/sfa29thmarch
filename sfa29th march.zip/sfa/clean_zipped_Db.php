<?php
unlink('*.sql.zip');
?>