     <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

              <div class="row" >
              
                  <div class="col-lg-9" style="padding-top:10px">
                 
                  <!-- *******************************************************************-->
                 
                    <!--start first div-->
                  <div class="col-md-4 mb">
							<!-- WHITE PANEL - TOP USER -->
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Gaps and Training needs</h5>
								</div>
								<p><img src="assets/img/list.png" width="80"></p>
								<p><b>As captured</b></p>
									<div class="row">
											<a href="clusters.php?mode=area&area_id=<?php echo  $_SESSION['area_id'];?>"><span class="btn btn-small btn-success">Click here</span></a>
									</div>
							</div>
						</div><!-- /col-md-4 -->
                        <!--end first div-->
                 <!-- *******************************************************************-->
                  <!-- *******************************************************************-->
                    <!--start first div-->
                  <div class="col-md-4 mb">
							<!-- WHITE PANEL - TOP USER -->
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Appraisal Plans</h5>
								</div>
								<p><img src="assets/img/assign_cluster_AD.png" class="" width="90"></p>
								<p><b>Assign AD clusters to Individual ADs</b></p>
									<div class="row">
											<a href="assign_adClusters2ADs.php"><span class="btn btn-small btn-success">Click here</span></a>
									</div>
							</div>
						</div><!-- /col-md-4 -->
                        <!--end first div-->
                 <!-- *******************************************************************-->
                 <div class="col-md-4 mb">
							<!-- WHITE PANEL - TOP USER -->
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Marketing materials</h5>
								</div>
								<p><img src="images/assign.png" alt="assign routes To ad clusters" width="100" class="" /></p>
								<p><b>Sub Areas within by Area</b></p>
									<div class="row">
											<a href="assign_routes2adClusters.php?mode=area&area_id=<?php echo  $_SESSION['area_id'];?>"><span class="btn btn-small btn-success">Click here</span></a>
									</div>
							</div>
						</div><!-- /col-md-4 -->
                        <!--end first div-->
                 <!-- *******************************************************************-->
                  <!-- *******************************************************************-->
                    <!--start first div-->
                  <div class="col-md-4 mb">
							<!-- WHITE PANEL - TOP USER -->
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Visit Plans and schedules</h5>
								</div>
								<p><img src="assets/img/deliver_icon.jpg" class="" width="100"></p>
								<p><b>Details about Visits </b></p>
									<div class="row">
											<a href="deliveries.php"><span class="btn btn-small btn-success">Click here</span></a>
									</div>
							</div>
						</div><!-- /col-md-4 -->
                        <!--end first div-->
                 <!-- *******************************************************************-->
                 <div class="col-md-4 mb">
							<!-- WHITE PANEL - TOP USER -->
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Report on Gold scored</h5>
								</div>
								<p><img src="assets/img/route_icon.jpg" width="100"></p>
								<p><b>Test</b></p>
									<div class="row">
											<a href="clusters.php?mode=area&area_id=<?php echo  $_SESSION['area_id'];?>"><span class="btn btn-small btn-success">Click here</span></a>
									</div>
							</div>
						</div><!-- /col-md-4 -->
                        <!--end first div-->
                 <!-- *******************************************************************-->
                 
                    <!--start first div-->
                  <div class="col-md-4 mb">
							<!-- WHITE PANEL - TOP USER -->
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Payments/collections</h5>
								</div>
								<img src="assets/img/payments_icon.jpg" class="img-circle" width="100">
								<p><b>Receive and issue Receipts </b></p>
									<div class="row">
											<a href="clients_collect_cash.php"><span class="btn btn-small btn-success">Click here</span></a>
									</div>
							</div>
						</div><!-- /col-md-4 -->
                        <!--end first div-->
                 <!-- *******************************************************************-->
                         
                      
                  
                  </div><!--end col-lg-9 main chart
                  
      <!-- 