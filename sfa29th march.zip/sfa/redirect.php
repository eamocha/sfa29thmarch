<?php
session_start();
$_SESSION['ppt']='no';
header('location:index.php');
?>