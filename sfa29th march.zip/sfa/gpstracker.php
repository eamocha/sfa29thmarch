<!DOCTYPE html>
<html>

<script type="text/javascript" src="assets/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="tests/track.js"></script>
<script>
startTracking();
</script>
</head>
<body>

</body></html>