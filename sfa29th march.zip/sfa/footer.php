 <footer class="site-footer">
 <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
          <div class="text-center">
             &copy; <?php echo date('Y').' Distribution Management System'?>
              <a href="index.php#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>