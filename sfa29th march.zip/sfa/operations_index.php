 <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

              <div class="row">
              <div class="col-lg-9 main-chart">
    
                                    
                             
                   
                 <table width="100%" style="padding:10px; vertical-align:top">
                   <tr>
                     <td colspan="3"><h3>REPORTS DASHBOARD </h3></td>
                   </tr>
                   <tr>
                     <td valign="top">Sales
                       <ul style="list-style-type:square">
                       <li><a href="survey_report_operations.php">Survey Report</a></li>
                       <li><a href="sales_by_brand.php">By Brand</a></li>
                       <li><a href="sales_by_outlet.php">By Outlet</a></li>
                       <li><a href="sales_by_salesperson.php">By Salesperson</a></li>
                       <li><a href="sales_per_region.php">By Region</a></li>
                       <li><a href="sales_summary.php">By Sumary</a></li>
                       <li><a href="targets.php">Sales Targets</a></li>
                     </ul></td>
                     <td valign="top">Orders
                       <ul>
                         <li><a href="upcoming_orders_report.php">Upcoming</a></li>
                         <li><a href="expired_orders_report.php">Expired Orders</a></li>
                         <li><a href="delivered_orders_report.php">Delivered</a></li>
                         <li><a href="order_rejected.php">Rejected</a></li>
                         <li><a href="orders_summary.php">Summary</a></li>
                     </ul></td>
                     <td valign="top">Outlets
                       <ul>
                         <li><a href="all_outlets.php">Outlets List</a></li>
                         <li><a href="new_outlets.php">New Outlets</a></li>
                         <li><a href="new_outlet_listing.php">New Outlets listing</a></li>
                          <li><a href="outlet_categories.php">By categories</a></li>
                         <li><a href="deleted_outlets.php">Deleted Outlets</a></li>
                         <li><a href="outlet_visit_status.php">Dormant Outlets</a></li>
                     </ul></td>
                 </tr>
                   <tr valign="top">
                     <td valign="top">Stock
                       <ul>
                         <li><a href="stock_summary.php">Product details</a></li>
                         <li><a href="stock_status.php">Holding Status</a><a href="#"></a></li>
                         <li><a href="stock_sales.php">Sales</a></li>
                         <li><a href="tsr_stock_holding.php">ADS Stock Holding</a></li>
                         <li><a href="stock_levels.php">By outlet</a></li>
                       </ul>
                     <p>Staff  Perfomance</p>
                     <ul>
                       <li><a href="route_completion.php">Route completion -ADS </a></li>
                        <li><a href="region_report.php">Route completion-regions </a></li>
                       <li><a href="monthly_plans.php">Route Completion Summary (r4)</a></li>
                        <li><a href="monthly_plans.php">Route Completion Detailed (r5)</a></li>
                         
                       <li><a href="daily_perfomance.php">Daily performance </a></li>
                       <li><a href="fullcalendar/index.php">ADS Plans Calender</a></li>
                       <li><a href="tsr_plan_lists.php">ADs Plans List</a></li>
                    
                       <li><a href="monthly_plans.php">Monthly ADs Plan Lists</a></li>
                            <li><a href="daily_sell_out_report.php">Daily sell out report</a></li>
<li><a href="checkin_time.php">Checkin Time</a></li>
                        

                     </ul></td>
                     <td valign="top">Payments
                       <ul>
                         <li><a href="list_ofpayments.php">List of Payments</a></li>
                         <li><a href="payments_by_outlet.php">By Outlet</a></li>
                         <li><a href="payements_by_month.php">By  Month</a></li>
                          <li><a href="mode_of_payments.php">Mode of Payment</a></li>
                       </ul>
                     <p> Productivity Reports</p>
                     <ul>
                       <li><a href="workbook.php">Regional </a></li>
                       <li><a href="month_daily.php">AD Daily</a></li>
                       <li><a href="monthly_plans.php">Report 2</a></li>
                           <li><a href="monthly_plans.php">Report 3</a></li>
                       </ul>
                     <p>Others</p>
                     <ul>
                       <li><a href="settings.php">Settings</a></li>
                        <li><a href="stocking_settings.php">Standard stocking amounts</a></li>
                       <li><a href="competitors.php">Competitors</a></li>
                        <li><a href="couching_plans.php">Couching Plans</a></li>
                        <li><a href="good_morning_meetings.php">Good Morning Meetings</a></li>
                        <li><a href="visit_objectives.php">Visit Objectives</a></li> 
                       
                     </ul>
                     <p>&nbsp;</p></td>
                     <td valign="top">Assets/Marketing/Visibility
                       <ul>
                         <li><a href="assetreports.php">Asset Categories</a></li>
                         <li><a href="assetby_region.php">By Region</a></li>
                         <li><a href="verified_assets.php"> Promotions</a></li>
                         <li><a href="photos.php">Photos from outlet visits</a></li>
                         <li>Sales Drivers</li>
                         <li>Issues/Concens</li>
                         <li>Quality</li>
                         <li>Distribution</li>
                         <li>Pricing details</li>
                         
                       </ul>
                     <p>Graphical Representations</p>
                     <ul>
                       <li><a href="">Regional </a></li>
                       <li><a href="">Sales</a></li>
                       <li><a href="">Stock Levels</a></li>
                       <li><a href="">Visits</a></li>
                     </ul>
                     <p>Assets Management</p>
                     <ul>
                       <li><a href="assets.php">Asset List</a> </li>
                       <li><a href="assetreports.php">Asset Categories</a></li>
                       <li><a href="assets.php">Asset Requests</a></li>
                       <li><a href="assetreports.php">Asset Movement</a></li>
                       <li><a href="assets.php">Faulty assets</a></li>
                       <li><a href="assetreports.php">Asset Categories</a></li>
                     </ul>
                     <p>&nbsp;</p></td>
                   </tr>
                 </table>
                 </span>
                          </div>
                          <script>
 $(document).ready(function(e) {
	 
        //load the the data
		//var dat=<?php //echo strtotime($date)?>; var tsr=1;
//var url="report_sections/dashboard.php?date="+dat+"&tsr="+tsr;
	//$("#content_div").load(url);
    });
    </script>   
    
                 