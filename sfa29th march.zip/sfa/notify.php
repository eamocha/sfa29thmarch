
                       
                        <!-- Modal -->
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						  <div class="modal-dialog ">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title" id="myModalLabel">Notification Details on trip ABC (client A)</h4>
						      </div>
						      <div class="modal-body">
						       
                 <form name="signupForm" id="signupForm" action="" method="post">
                               <table id="add_users"  style="margin:auto;"><tr>
                                   <td>About</td><td><input type="text" class=" form-control" id="full_name" name="full_name"></td>
                               <td>Priority</td>
                               <td><select><option> high</option><option> Medium</option><option> Low</option></select></td>
                               <td>To</td><td><select> <option> All</option><option> Eric</option><option> Steve</option> </select></td></tr>
                               <tr>
                                 <td>Details</td>
                                 <td colspan="5"><label for="description"></label>
                                 <textarea name="description" id="description" cols="45" rows="5"></textarea></td>
                               </tr></table>
                              <div class="modal-footer">
						        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						        <button  type="submit" class="btn btn-primary">Save</button>
						      </div></form>
						    </div>
						     				
      				