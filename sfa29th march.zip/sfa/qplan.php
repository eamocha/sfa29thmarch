
						<!-- Modal -->
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						  <div class="modal-dialog ">
						    <div class="modal-content">
						      <div class="modal-header">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title" id="myModalLabel">Outlet plan</h4>
						      </div>
						      <div class="modal-body">
						       
                 <form class="cmxform form-horizontal style-form"  onSubmit="return false" id="commentForm" method="post" action="">
                                <table id="add_users"><tr>
                                  <td>Date 1</td>
                                 <td><input type="text" class="form-control  dpd1" name="date" value="<?php ?>" /></td>
                                 <td>Date2</td><td><input placeholder="Name of person" class="form-control " id="decision_maker3" type="phone" name="decision_maker3" /></td>
                                 </tr>
                               <tr>
                                 <td>Date3</td>
                                 <td><input placeholder="Name of person" class="form-control " id="decision_maker4" type="phone" name="decision_maker4" /></td>
                                 <td>Date4</td>
                                 <td><input type="text" class=" form-control" name="phone" id="phone"></td>
                                 </tr>
                                 <tr>
                                   <td colspan="4"><input type="hidden"  class=" form-control" id="lat" name="lat" />
                                     </select>
                                     <input  type="hidden" class=" form-control" id="long" name="long" />
                                     <button class="btn btn-default" data-dismiss="modal" type="reset">Cancel</button>
                                   <button class="btn btn-success" data-dismiss="modal" onclick="add_prospecting();" type="submit">Save</button></td>
                                  </tr>
                                </table>
                                  <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10"></div>
                   </div>
                            </form>
						    </div>
						  </div>
						</div>      				
      				</div><!-- /showback -->
                    
                    
                    
                   